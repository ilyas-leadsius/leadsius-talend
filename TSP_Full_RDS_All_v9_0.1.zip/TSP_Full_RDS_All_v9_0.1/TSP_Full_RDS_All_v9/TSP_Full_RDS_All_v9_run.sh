cd `dirname $0`
 ROOT_PATH=`pwd`
java -Xms256M -Xmx7000M -cp classpath.jar: dw.tsp_full_rds_all_v9_0_1.TSP_Full_RDS_All_v9 --context=Default "$@" 